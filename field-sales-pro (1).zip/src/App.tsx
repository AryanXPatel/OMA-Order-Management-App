import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MobileLayout from './components/MobileLayout';
import Dashboard from './pages/Dashboard';
import Orders from './pages/Orders';
import Clients from './pages/Clients';
import Approvals from './pages/Approvals';
import NewOrder from './pages/NewOrder';
import Analytics from './pages/Analytics';
import OrderDetails from './pages/OrderDetails';
import ClientDetails from './pages/ClientDetails';

export type Role = 'owner' | 'manager' | 'worker';
export const RoleContext = React.createContext<{ role: Role; setRole: (r: Role) => void }>({ role: 'owner', setRole: () => {} });

export default function App() {
  const [role, setRole] = useState<Role>('owner');

  return (
    <RoleContext.Provider value={{ role, setRole }}>
      <BrowserRouter>
        <Routes>
          <Route element={<MobileLayout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/approvals" element={<Approvals />} />
            <Route path="/analytics" element={<Analytics />} />
          </Route>
          <Route path="/new-order" element={<NewOrder />} />
          <Route path="/orders/:id" element={<OrderDetails />} />
          <Route path="/clients/:id" element={<ClientDetails />} />
        </Routes>
      </BrowserRouter>
    </RoleContext.Provider>
  );
}

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Search, ChevronRight, CheckCircle2, ChevronLeft, Plus, Minus } from 'lucide-react';

export default function NewOrder() {
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [cart, setCart] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const products = [
    { id: 'p1', name: 'Industrial Solvent 50L', price: 120.00, stock: 500 },
    { id: 'p2', name: 'Titanium Widget A4', price: 45.50, stock: 1200 },
    { id: 'p3', name: 'Heavy Duty Crate (Pack 10)', price: 89.99, stock: 150 },
    { id: 'p4', name: 'Machine Grease 5L', price: 29.50, stock: 45 },
  ];

  const handleAdd = (id: string) => setCart(p => ({ ...p, [id]: (p[id] || 0) + 1 }));
  const handleSub = (id: string) => setCart(p => {
    const next = { ...p, [id]: Math.max(0, (p[id] || 0) - 1) };
    if (next[id] === 0) delete next[id];
    return next;
  });

  const total = products.reduce((acc, p) => acc + (cart[p.id] || 0) * p.price, 0);
  const totalItems = Object.values(cart).reduce((a: number, b: number) => a + b, 0);

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      navigate('/orders'); // Redirect to orders upon success
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#000000] flex justify-center font-sans sm:py-8 lg:p-12 text-white">
      <div className="w-full max-w-[414px] bg-[#121212] sm:rounded-[56px] min-h-[100dvh] sm:min-h-[896px] shadow-2xl relative flex flex-col overflow-hidden sm:ring-[6px] sm:ring-[#2C2C2E] animate-in slide-in-from-bottom-full duration-300">
        
        {/* Header */}
        <div className="pt-14 pb-4 px-5 flex items-center justify-between border-b border-white/[0.06] bg-[#1C1C1E] z-10 shrink-0">
          <button 
            onClick={() => step === 1 ? navigate('/') : setStep((s) => s - 1 as any)}
            className="w-10 h-10 rounded-full bg-[#242426] flex items-center justify-center text-white hover:bg-white/10 transition-colors"
          >
            {step === 1 ? <X className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          </button>
          
          <div className="flex gap-1.5 items-center object-center">
            <div className={`h-2 rounded-full transition-all ${step >= 1 ? 'w-4 bg-white' : 'w-2 bg-white/20'}`} />
            <div className={`h-2 rounded-full transition-all ${step >= 2 ? 'w-4 bg-white' : 'w-2 bg-white/20'}`} />
            <div className={`h-2 rounded-full transition-all ${step >= 3 ? 'w-4 bg-[#10B981]' : 'w-2 bg-white/20'}`} />
          </div>

          <div className="w-10"></div> {/* Spacer for centering */}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto px-5 pt-6 pb-32">
          
          {/* STEP 1: Select Client */}
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
              <h3 className="text-[24px] font-bold tracking-tight mb-6">Select Client</h3>
              
              <div className="relative mb-6">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" strokeWidth={2} />
                <input 
                  type="text" 
                  autoFocus
                  placeholder="Search clients..." 
                  className="w-full bg-[#1C1C1E] text-white placeholder-zinc-500 text-[16px] rounded-2xl py-4 pl-12 pr-4 outline-none focus:ring-2 focus:ring-[#EAB308]/50 transition-all font-medium tracking-tight shadow-sm border border-white/[0.04]"
                />
              </div>

              <div className="text-[13px] font-bold text-zinc-500 uppercase tracking-[0.08em] mb-3 ml-1">
                Recent Clients
              </div>

              <div className="space-y-3">
                {[
                  { id: 'c1', name: 'Stark Industries', loc: 'New York, NY', tag: 'Preferred' },
                  { id: 'c2', name: 'Wayne Enterprises', loc: 'Gotham, NJ', tag: 'Net-30' },
                  { id: 'c3', name: 'Acme Corp', loc: 'Los Angeles, CA', tag: 'COD' },
                ].map((client) => (
                  <div 
                    key={client.id} 
                    onClick={() => setSelectedClient(client)}
                    className={`rounded-[20px] p-4 flex items-center justify-between border cursor-pointer transition-all ${selectedClient?.id === client.id ? 'bg-[#EAB308]/10 border-[#EAB308]/50' : 'bg-[#1C1C1E] border-white/[0.02] hover:bg-[#242426]'}`}
                  >
                    <div>
                      <h4 className="text-[17px] font-bold tracking-tight text-white mb-0.5">{client.name}</h4>
                      <p className="text-[14px] font-medium text-zinc-500 tracking-tight">{client.loc}</p>
                    </div>
                    {selectedClient?.id === client.id ? (
                      <CheckCircle2 className="text-[#EAB308] w-6 h-6" />
                    ) : (
                      <div className="bg-[#242426] px-3 py-1.5 rounded-lg text-[12px] font-bold tracking-tight text-zinc-300">
                        {client.tag}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: Add Products */}
          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="mb-6">
                <h3 className="text-[24px] font-bold tracking-tight mb-1">Add Products</h3>
                <p className="text-zinc-500 font-medium tracking-tight">Ordering for {selectedClient?.name}</p>
              </div>

              <div className="space-y-3">
                {products.map((p) => {
                  const qty = cart[p.id] || 0;
                  return (
                    <div key={p.id} className="bg-[#1C1C1E] p-4 rounded-[20px] flex items-center justify-between">
                      <div className="flex-1 pr-3">
                         <h4 className="text-[16px] font-bold text-white tracking-tight mb-0.5">{p.name}</h4>
                         <div className="flex items-center gap-2">
                            <span className="text-[15px] font-semibold text-[#10B981]">${p.price.toFixed(2)}</span>
                            <span className="text-[12px] text-zinc-500 font-medium">({p.stock} in stock)</span>
                         </div>
                      </div>
                      
                      <div className="flex items-center gap-4 bg-[#242426] rounded-full p-1 border border-white/[0.06]">
                         <button 
                           onClick={() => handleSub(p.id)}
                           className={`w-8 h-8 flex items-center justify-center rounded-full transition-colors ${qty > 0 ? 'bg-white text-black' : 'text-zinc-500'}`}
                         >
                           <Minus className="w-4 h-4" />
                         </button>
                         <span className="w-4 text-center font-bold tracking-tight">{qty}</span>
                         <button 
                           onClick={() => handleAdd(p.id)}
                           className="w-8 h-8 flex items-center justify-center rounded-full bg-white text-black"
                         >
                           <Plus className="w-4 h-4" />
                         </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* STEP 3: Review */}
          {step === 3 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
              <h3 className="text-[24px] font-bold tracking-tight mb-6">Review Order</h3>
              
              <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04] mb-4">
                 <div className="text-[13px] font-bold text-zinc-500 uppercase tracking-[0.08em] mb-2">Ship To</div>
                 <h4 className="text-[18px] font-bold text-white tracking-tight mb-1">{selectedClient?.name}</h4>
                 <p className="text-[14px] text-zinc-400 font-medium tracking-tight">{selectedClient?.loc}</p>
                 <div className="mt-3 inline-block bg-[#EAB308]/10 text-[#EAB308] px-3 py-1 rounded-md text-[13px] font-bold tracking-tight">Terms: {selectedClient?.tag}</div>
              </div>

              <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04]">
                 <div className="text-[13px] font-bold text-zinc-500 uppercase tracking-[0.08em] mb-4">Order Summary ({totalItems} Items)</div>
                 
                 <div className="space-y-3 mb-4">
                   {products.filter(p => cart[p.id] > 0).map(p => (
                     <div key={p.id} className="flex justify-between items-center text-[15px] font-medium tracking-tight">
                       <span className="text-zinc-300">{cart[p.id]}x {p.name}</span>
                       <span>${(cart[p.id] * p.price).toFixed(2)}</span>
                     </div>
                   ))}
                 </div>

                 <div className="border-t border-white/[0.1] pt-4 flex justify-between items-center">
                    <span className="text-[18px] font-medium tracking-tight text-zinc-400">Total</span>
                    <span className="text-[24px] font-bold tracking-tight leading-none">${total.toFixed(2)}</span>
                 </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Action */}
        <div className="p-5 border-t border-white/[0.06] bg-[#121212]/90 backdrop-blur-md absolute bottom-0 left-0 right-0">
            {step === 1 && (
               <button 
                 disabled={!selectedClient}
                 onClick={() => setStep(2)}
                 className={`w-full font-bold text-[17px] tracking-tight py-4 rounded-full transition-colors flex items-center justify-center gap-2 ${selectedClient ? 'bg-white text-black cursor-pointer shadow-lg' : 'bg-zinc-800 text-zinc-500 opacity-50 cursor-not-allowed'}`}
               >
                 Continue to Products <ChevronRight className="w-5 h-5" />
               </button>
            )}

            {step === 2 && (
               <div className="flex gap-4 items-center">
                 <div className="flex flex-col">
                   <span className="text-[12px] text-zinc-500 font-bold uppercase tracking-widest leading-none mb-1">Total</span>
                   <span className="text-[20px] font-bold leading-none tracking-tight">${total.toFixed(2)}</span>
                 </div>
                 <button 
                   disabled={total === 0}
                   onClick={() => setStep(3)}
                   className={`flex-1 font-bold text-[17px] tracking-tight py-4 rounded-full transition-colors flex items-center justify-center gap-2 ${total > 0 ? 'bg-white text-black cursor-pointer shadow-lg' : 'bg-zinc-800 text-zinc-500 opacity-50 cursor-not-allowed'}`}
                 >
                   Review Order <ChevronRight className="w-5 h-5" />
                 </button>
               </div>
            )}

            {step === 3 && (
               <button 
                 onClick={handleSubmit}
                 disabled={isSubmitting}
                 className="w-full bg-[#10B981] hover:bg-[#059669] text-white font-bold text-[17px] tracking-tight py-4 rounded-full transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
               >
                 {isSubmitting ? (
                   <span className="animate-pulse">Processing...</span>
                 ) : (
                   <>Confirm Order <CheckCircle2 className="w-5 h-5" /></>
                 )}
               </button>
            )}
        </div>

      </div>
    </div>
  );
}

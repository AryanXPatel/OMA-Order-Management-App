import React from 'react';
import { ChevronLeft, ArrowUpRight, CheckCircle2, TrendingUp, CalendarDays, Receipt } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';

export default function ClientDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  // Mock checking ID to customize view slightly
  const isStark = id === 'Stark Industries';

  return (
    <div className="min-h-screen bg-[#000000] flex justify-center font-sans sm:py-8 lg:p-12 text-white">
      <div className="w-full max-w-[414px] bg-[#121212] sm:rounded-[56px] min-h-[100dvh] sm:min-h-[896px] shadow-2xl relative flex flex-col overflow-hidden sm:ring-[6px] sm:ring-[#2C2C2E] animate-in slide-in-from-right-8 duration-300">
        
        {/* Header */}
        <div className="pt-14 pb-2 px-5 flex items-center justify-between z-10 shrink-0">
          <button 
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-[#242426] flex items-center justify-center text-white hover:bg-white/10 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-[14px] font-bold tracking-[0.05em] uppercase text-zinc-500">Customer Ledger</div>
          <div className="w-10"></div> {/* Spacer */}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto px-5 pt-4 pb-32">
            
            {/* Identity Profile */}
            <div className="flex flex-col items-center mb-8">
              <div className={`w-[88px] h-[88px] rounded-[32px] flex items-center justify-center text-[36px] font-bold tracking-tight mb-4 shadow-lg ${isStark ? 'bg-[#60A5FA]/20 text-[#60A5FA] border border-[#60A5FA]/30' : 'bg-[#EAB308]/20 text-[#EAB308] border border-[#EAB308]/30'}`}>
                {isStark ? 'SI' : 'GE'}
              </div>
              <h2 className="text-[26px] leading-tight font-bold tracking-tight text-center">{id || 'Globex Inc'}</h2>
              <div className="flex items-center gap-2 mt-2">
                 <span className="text-[14px] text-zinc-400 font-medium tracking-tight bg-[#1C1C1E] px-3 py-1 rounded-full border border-white/[0.04]">New York, NY</span>
                 <span className="text-[14px] text-zinc-400 font-medium tracking-tight bg-[#1C1C1E] px-3 py-1 rounded-full border border-white/[0.04]">Manufacturing</span>
              </div>
            </div>

            {/* Credit / Ledger Block */}
            <div className="bg-[#1C1C1E] rounded-[28px] p-6 shadow-sm border border-white/[0.04] mb-8 relative overflow-hidden">
               {/* Ambient Glow */}
               <div className={`absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none ${isStark ? 'bg-[#60A5FA]' : 'bg-[#EAB308]'}`}></div>

               <div className="flex justify-between items-end mb-6 relative z-10">
                 <div>
                   <div className="text-[13px] text-zinc-400 font-bold uppercase tracking-[0.05em] mb-1">Utilized Credit</div>
                   <div className="flex items-baseline gap-1">
                      <span className="text-[32px] font-bold tracking-tight text-white leading-none">{isStark ? '$24,050' : '$12,400'}</span>
                      <span className="text-[16px] font-bold text-zinc-500 tracking-tight">.00</span>
                   </div>
                 </div>
                 <div className="text-right">
                   <div className="text-[12px] text-zinc-500 font-bold uppercase tracking-[0.05em] mb-1">Total Limit</div>
                   <div className="text-[18px] font-bold tracking-tight text-white">{isStark ? '$150,000' : '$50,000'}</div>
                 </div>
               </div>

               {/* Progress Bar */}
               <div className="h-2.5 w-full bg-[#121212] rounded-full overflow-hidden relative z-10 mb-4 shadow-inner">
                  <div className={`h-full rounded-full transition-all duration-1000 ${isStark ? 'bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] w-[16%]' : 'bg-gradient-to-r from-[#EAB308] to-[#FDE047] w-[24%]'}`}></div>
               </div>

               <div className="flex items-center gap-2 text-[13px] font-bold text-[#10B981] tracking-tight bg-[#10B981]/10 px-3 py-2 rounded-xl w-fit">
                  <CheckCircle2 className="w-4 h-4" /> Account is in good standing
               </div>
            </div>

            {/* Recent Orders (Ledger) */}
            <div className="flex items-center justify-between mb-5 px-1">
               <h3 className="text-[20px] font-bold tracking-tight text-white flex items-center gap-2">
                 <Receipt className="w-[20px] h-[20px] text-zinc-400" /> Recent Invoices
               </h3>
               <button className="text-[14px] text-zinc-400 font-bold tracking-tight hover:text-white transition-colors">See all</button>
            </div>

            <div className="space-y-3">
               {[
                 { id: 'INV-4402', date: 'Apr 18', amt: '$4,200', st: 'Unpaid', statCol: 'text-white' },
                 { id: 'INV-4390', date: 'Apr 02', amt: '$12,050', st: 'Settled', statCol: 'text-[#10B981]' },
                 { id: 'INV-4311', date: 'Mar 15', amt: '$8,400', st: 'Settled', statCol: 'text-[#10B981]' },
               ].map((inv) => (
                 <div key={inv.id} className="bg-[#1C1C1E] p-4 flex items-center justify-between rounded-[20px] border border-white/[0.02]">
                    <div className="flex items-center gap-4">
                       <div className="bg-[#242426] p-3 rounded-2xl text-zinc-300">
                         <CalendarDays className="w-5 h-5" />
                       </div>
                       <div>
                          <div className="font-bold text-[16px] tracking-tight text-white mb-0.5">{inv.id}</div>
                          <div className={`font-semibold text-[13px] tracking-tight ${inv.statCol}`}>{inv.st} • {inv.date}</div>
                       </div>
                    </div>
                    <div className="text-[17px] font-bold tracking-tight text-white">
                      {inv.amt}
                    </div>
                 </div>
               ))}
            </div>

        </div>

      </div>
    </div>
  );
}

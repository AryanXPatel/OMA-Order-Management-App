import React from 'react';
import { Search, ArrowUpRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Clients() {
  const navigate = useNavigate();

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 mt-2 px-5">
      <h1 className="text-[28px] font-bold tracking-tight mb-4 flex items-center justify-between">
        Clients
        <button className="text-[15px] font-bold text-[#EAB308] tracking-tight bg-[#EAB308]/10 px-3 py-1.5 rounded-full">+ New Client</button>
      </h1>
      
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" strokeWidth={2} />
        <input 
          type="text" 
          placeholder="Search clients, industries..." 
          className="w-full bg-[#1C1C1E] text-white placeholder-zinc-500 text-[16px] rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:ring-2 focus:ring-white/10 transition-all font-medium tracking-tight"
        />
      </div>

      {/* Client List */}
      <div className="space-y-3 pb-8">
        {[
          { name: 'Stark Industries', ini: 'SI', bg: 'bg-[#60A5FA]/20', col: 'text-[#60A5FA]', limit: '$150k limit', balance: '$24k due' },
          { name: 'Wayne Enterprises', ini: 'WE', bg: 'bg-[#10B981]/20', col: 'text-[#10B981]', limit: '$200k limit', balance: 'Settled' },
          { name: 'Acme Corp', ini: 'AC', bg: 'bg-[#F87171]/20', col: 'text-[#F87171]', limit: '$10k limit', balance: '$4.2k due' },
          { name: 'Globex Inc', ini: 'GI', bg: 'bg-[#EAB308]/20', col: 'text-[#EAB308]', limit: '$50k limit', balance: '$12k due' },
        ].map((client) => (
          <div 
            key={client.name} 
            onClick={() => navigate(`/clients/${client.name}`)}
            className="bg-[#1C1C1E] border border-white/[0.02] hover:bg-[#242426] rounded-[20px] p-4 flex items-center gap-4 cursor-pointer transition-colors active:scale-[0.98]"
          >
            <div className={`w-[48px] h-[48px] rounded-full flex items-center justify-center font-bold text-[18px] tracking-tight shrink-0 ${client.bg} ${client.col}`}>
              {client.ini}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-[17px] font-bold tracking-tight text-white truncate leading-tight">{client.name}</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[13px] text-zinc-400 font-medium tracking-tight">{client.limit}</span>
                <span className="w-1 h-1 rounded-full bg-zinc-600"></span>
                <span className="text-[13px] text-zinc-400 font-medium tracking-tight">{client.balance}</span>
              </div>
            </div>
            <div className="flex flex-col gap-2 shrink-0">
              <button className="w-[32px] h-[32px] rounded-full bg-[#121212] flex items-center justify-center text-white/80 hover:text-white transition-colors">
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

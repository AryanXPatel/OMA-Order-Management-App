import React from 'react';
import { BadgeDollarSign } from 'lucide-react';

export default function Approvals() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 mt-2 px-5">
      <h1 className="text-[28px] font-bold tracking-tight mb-6">Approvals</h1>

      <div className="flex gap-2 overflow-x-auto pb-4 mb-2 [&::-webkit-scrollbar]:hidden">
        <button className="shrink-0 px-4 py-2 rounded-full text-[14px] font-semibold tracking-tight transition-colors bg-white text-black">
          Action Required (2)
        </button>
        <button className="shrink-0 px-4 py-2 rounded-full text-[14px] font-semibold tracking-tight transition-colors bg-[#1C1C1E] text-zinc-400">
          History
        </button>
      </div>

      {/* Approval Cards */}
      <div className="space-y-4">
        {/* Approval Card 1 */}
        <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04]">
            <div className="flex justify-between items-start mb-4">
                <div className="flex gap-3">
                  <div className="w-[36px] h-[36px] rounded-full bg-[#F87171]/20 flex items-center justify-center shrink-0">
                      <BadgeDollarSign className="w-[18px] h-[18px] text-[#F87171]" strokeWidth={2.5} />
                  </div>
                  <div>
                    <h3 className="text-[18px] text-white font-bold tracking-tight leading-tight">Acme Corp</h3>
                    <p className="text-[14px] text-zinc-400 font-medium tracking-tight mt-0.5">Order #ORD-989</p>
                  </div>
                </div>
                <div className="text-[17px] text-white font-bold tracking-tight">$4,200.00</div>
            </div>
            
            <div className="bg-[#242426] rounded-[16px] p-3.5 mb-5 border border-[#F87171]/20">
              <div className="text-[13px] font-bold text-[#F87171] uppercase tracking-[0.05em] mb-1">Risk Override Needed</div>
              <p className="text-[14px] text-zinc-300 leading-snug tracking-tight">
                Client has exceeded their current soft limit of $10k. Current outstanding balance is $4.2k. Proceed with order?
              </p>
            </div>

            <div className="flex gap-3">
              <button className="flex-1 bg-white/10 hover:bg-white/15 text-white font-semibold py-3 rounded-[16px] tracking-tight transition-colors">
                Decline
              </button>
              <button className="flex-1 bg-white text-black hover:bg-white/90 font-bold py-3 rounded-[16px] tracking-tight transition-colors shadow-lg">
                Override & Approve
              </button>
            </div>
        </div>

        {/* Approval Card 2 */}
        <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04]">
            <div className="flex justify-between items-start mb-4">
                <div className="flex gap-3">
                  <div className="w-[36px] h-[36px] rounded-full bg-[#EAB308]/20 flex items-center justify-center shrink-0">
                      <BadgeDollarSign className="w-[18px] h-[18px] text-[#EAB308]" strokeWidth={2.5} />
                  </div>
                  <div>
                    <h3 className="text-[18px] text-white font-bold tracking-tight leading-tight">Globex Inc</h3>
                    <p className="text-[14px] text-zinc-400 font-medium tracking-tight mt-0.5">Order #ORD-990</p>
                  </div>
                </div>
                <div className="text-[17px] text-white font-bold tracking-tight">$850.00</div>
            </div>
            
            <div className="bg-[#242426] rounded-[16px] p-3.5 mb-5 border border-[#EAB308]/20">
              <div className="text-[13px] font-bold text-[#EAB308] uppercase tracking-[0.05em] mb-1">Discount Approval</div>
              <p className="text-[14px] text-zinc-300 leading-snug tracking-tight">
                Rep requested a 15% promotional discount on the SKU "Industrial Solvents". Max auto-approve is 10%.
              </p>
            </div>

            <div className="flex gap-3">
              <button className="flex-1 bg-white/10 hover:bg-white/15 text-white font-semibold py-3 rounded-[16px] tracking-tight transition-colors">
                Reject Discount
              </button>
              <button className="flex-1 bg-white text-black hover:bg-white/90 font-bold py-3 rounded-[16px] tracking-tight transition-colors shadow-lg">
                Approve Order
              </button>
            </div>
        </div>
      </div>
    </div>
  );
}

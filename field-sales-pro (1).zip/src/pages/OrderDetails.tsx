import React, { useContext, useState } from 'react';
import { ChevronLeft, Box, Truck, CheckCircle2, PackageOpen, MoreHorizontal, FileText, ClipboardList } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { RoleContext } from '../App';

export default function OrderDetails() {
  const navigate = useNavigate();
  const { role } = useContext(RoleContext);
  const { id } = useParams();
  
  // Simulated state for the order
  const [isDispatched, setIsDispatched] = useState(false);

  return (
    <div className="min-h-screen bg-[#000000] flex justify-center font-sans sm:py-8 lg:p-12 text-white">
      <div className="w-full max-w-[414px] bg-[#121212] sm:rounded-[56px] min-h-[100dvh] sm:min-h-[896px] shadow-2xl relative flex flex-col overflow-hidden sm:ring-[6px] sm:ring-[#2C2C2E] animate-in slide-in-from-bottom-full duration-300">
        
        {/* Header */}
        <div className="pt-14 pb-4 px-5 flex items-center justify-between border-b border-white/[0.06] bg-[#1C1C1E] z-10 shrink-0">
          <button 
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-[#242426] flex items-center justify-center text-white hover:bg-white/10 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h2 className="text-[18px] font-bold tracking-tight leading-none">Order #{id || '991'}</h2>
            <p className="text-[13px] text-zinc-400 font-medium tracking-tight mt-1">Wayne Enterprises</p>
          </div>
          <button className="w-10 h-10 rounded-full flex items-center justify-center text-white hover:bg-[#242426] transition-colors">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto px-5 pt-6 pb-32">
            
            {/* Status Tracker */}
            <div className="bg-[#1C1C1E] rounded-[24px] p-6 shadow-sm border border-white/[0.04] mb-6 relative overflow-hidden">
               <h3 className="text-[17px] font-bold tracking-tight text-white mb-6">Fulfillment Timeline</h3>
               
               <div className="flex items-start gap-4">
                 <div className="flex flex-col items-center mt-1">
                   {/* Step 1: Placed */}
                   <div className="w-8 h-8 rounded-full bg-[#10B981] flex items-center justify-center text-[#121212] shadow-[0_0_15px_rgba(16,185,129,0.3)] z-10">
                     <CheckCircle2 className="w-5 h-5" strokeWidth={2.5}/>
                   </div>
                   <div className="w-0.5 h-10 bg-[#10B981] -my-1 z-0"></div>
                   
                   {/* Step 2: Processing (Active or Done based on isDispatched) */}
                   {isDispatched ? (
                      <div className="w-8 h-8 rounded-full bg-[#10B981] flex items-center justify-center text-[#121212] shadow-[0_0_15px_rgba(16,185,129,0.3)] z-10 relative">
                        <CheckCircle2 className="w-5 h-5" strokeWidth={2.5}/>
                      </div>
                   ) : (
                      <div className="w-8 h-8 rounded-full bg-[#60A5FA] flex items-center justify-center text-[#121212] shadow-[0_0_15px_rgba(96,165,250,0.5)] z-10 relative">
                       <div className="absolute inset-0 bg-[#60A5FA] rounded-full animate-ping opacity-50 block"></div>
                        <Box className="w-4 h-4" strokeWidth={2.5} />
                      </div>
                   )}
                   
                   <div className={`w-0.5 h-10 -my-1 z-0 ${isDispatched ? 'bg-[#10B981]' : 'bg-zinc-800'}`}></div>

                   {/* Step 3: Dispatched */}
                   <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${isDispatched ? 'bg-[#EAB308] text-[#121212] shadow-[0_0_15px_rgba(234,179,8,0.5)]' : 'bg-zinc-800 text-zinc-500'}`}>
                     {isDispatched && <div className="absolute inset-0 bg-[#EAB308] rounded-full animate-ping opacity-50 block z-0"></div>}
                     <Truck className="w-4 h-4 relative z-10" strokeWidth={2.5} />
                   </div>
                 </div>

                 <div className="flex flex-col gap-5 text-[15px] font-medium tracking-tight">
                    <div className="h-8 flex flex-col justify-center">
                       <span className="text-white">Order Approved</span>
                       <span className="text-[12px] text-zinc-500">Today, 09:41 AM</span>
                    </div>
                    <div className="h-8 flex flex-col justify-center mt-2.5">
                       <span className={isDispatched ? "text-white" : "text-[#60A5FA]"}>Warehouse Processing</span>
                       <span className="text-[12px] text-zinc-500">Items being picked</span>
                    </div>
                    <div className="h-8 flex flex-col justify-center mt-2.5">
                       <span className={isDispatched ? "text-[#EAB308]" : "text-zinc-600"}>Out for Delivery</span>
                       <span className="text-[12px] text-zinc-600">Pending dispatch</span>
                    </div>
                 </div>
               </div>
            </div>

            {/* Line Items */}
            <h3 className="text-[18px] font-bold tracking-tight text-white mb-4 px-1 flex items-center gap-2">
               <ClipboardList className="w-5 h-5 text-zinc-400" /> Order Details
            </h3>

            <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04]">
               <div className="space-y-4">
                 {[
                   { id: '1', name: 'Industrial Solvent 50L', qty: 2, price: 240.00 },
                   { id: '2', name: 'Titanium Widget A4', qty: 10, price: 455.00 },
                   { id: '3', name: 'Heavy Duty Crate', qty: 3, price: 269.97 }
                 ].map((item) => (
                   <div key={item.id} className="flex justify-between items-start text-[15px] tracking-tight">
                      <div className="flex gap-3">
                         <div className="bg-[#242426] w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[13px] text-zinc-300">
                           {item.qty}x
                         </div>
                         <div>
                            <div className="font-semibold text-white">{item.name}</div>
                            <div className="text-[13px] text-zinc-500">Warehouse Isle B4</div>
                         </div>
                      </div>
                      <div className="font-bold">${item.price.toFixed(2)}</div>
                   </div>
                 ))}
               </div>

               <div className="border-t border-white/[0.06] mt-5 pt-4 flex justify-between items-center bg-[#242426] -mx-5 -mb-5 px-5 py-4 rounded-b-[24px]">
                  <span className="text-[15px] font-bold tracking-tight text-zinc-400">Total Purchase</span>
                  <span className="text-[22px] font-bold tracking-tight text-white">$964.97</span>
               </div>
            </div>
        </div>

        {/* Worker Dispatch Action Bar */}
        {role === 'worker' && !isDispatched && (
          <div className="p-5 border-t border-white/[0.06] bg-[#121212]/90 backdrop-blur-md absolute bottom-0 left-0 right-0 animate-in slide-in-from-bottom-full">
              <button 
                onClick={() => setIsDispatched(true)}
                className="w-full bg-[#60A5FA] hover:bg-[#3B82F6] text-black font-bold text-[17px] tracking-tight py-4 rounded-full transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(96,165,250,0.3)] shadow-[#60A5FA]/20 active:scale-[0.98]"
              >
                Scan & Dispatch <Truck className="w-5 h-5 ml-1" />
              </button>
          </div>
        )}

      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { Filter, Search, PackageOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Orders() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState('All Orders');

  const allOrders = [
    { id: '992', client: 'Stark Industries', status: 'Approved', color: '#10B981', amt: '$12,050.00' },
    { id: '991', client: 'Wayne Enterprises', status: 'Processing', color: '#60A5FA', amt: '$3,400.00' },
    { id: '990', client: 'Globex Inc', status: 'Pending Approval', color: '#EAB308', amt: '$850.00' },
    { id: '989', client: 'Acme Corp', status: 'Draft', color: '#9CA3AF', amt: '$4,200.00' },
  ];

  const filteredOrders = allOrders.filter(o => {
    if (activeFilter === 'All Orders') return true;
    if (activeFilter === 'Processing') return o.status === 'Processing';
    if (activeFilter === 'Delivered') return o.status === 'Delivered';
    if (activeFilter === 'Drafts') return o.status === 'Draft' || o.status === 'Pending Approval';
    return true;
  });

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 mt-2 px-5">
      <h1 className="text-[28px] font-bold tracking-tight mb-4 flex items-center justify-between">
        Orders
        <div className="bg-[#242426] p-2 rounded-full cursor-pointer hover:bg-white/10 transition-colors">
          <Filter className="w-5 h-5 text-zinc-400" />
        </div>
      </h1>
      
      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" strokeWidth={2} />
        <input 
          type="text" 
          placeholder="Search order ID or client..." 
          className="w-full bg-[#1C1C1E] text-white placeholder-zinc-500 text-[16px] rounded-2xl py-3.5 pl-12 pr-4 outline-none focus:ring-2 focus:ring-white/10 transition-all font-medium tracking-tight"
        />
      </div>

      {/* Horizontal Fillers */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-2 [&::-webkit-scrollbar]:hidden">
        {['All Orders', 'Drafts', 'Processing', 'Delivered'].map((filter) => (
          <button 
            key={filter} 
            onClick={() => setActiveFilter(filter)}
            className={`shrink-0 px-4 py-2 rounded-full text-[14px] font-semibold tracking-tight transition-colors ${activeFilter === filter ? 'bg-white text-black' : 'bg-[#1C1C1E] text-zinc-400 hover:text-white hover:bg-[#2C2C2E]'}`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Vertical Order List */}
      <div className="space-y-3 pb-8">
        {filteredOrders.length === 0 ? (
          <div className="flex flex-col items-center justify-center pt-16 pb-8 opacity-80">
            <PackageOpen className="w-16 h-16 text-zinc-600 mb-4 stroke-[1]" />
            <h3 className="text-[18px] font-bold tracking-tight mb-2 text-white">No Orders Found</h3>
            <p className="text-zinc-500 text-center text-[14px] px-8 font-medium">We couldn't find any orders matching the "{activeFilter}" filter.</p>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div 
              key={order.id} 
              onClick={() => navigate(`/orders/${order.id}`)}
              className="bg-[#1C1C1E] rounded-[20px] p-4 flex flex-col gap-3 active:scale-[0.98] transition-all cursor-pointer border border-white/[0.02] hover:bg-[#242426]"
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="text-[13px] font-bold text-zinc-300 bg-zinc-800 px-2 py-1 rounded-md">#ORD-{order.id}</span>
                  <span className="text-[13px] font-semibold tracking-tight" style={{ color: order.color }}>• {order.status}</span>
                </div>
                <span className="text-[14px] text-white font-bold tracking-tight">{order.amt}</span>
              </div>
              <div>
                <h3 className="text-[18px] font-bold tracking-tight text-white">{order.client}</h3>
                <div className="text-[13px] text-zinc-500 font-medium tracking-tight mt-0.5">14 Items • Expected dispatch tomorrow</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

import React from 'react';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, YAxis } from 'recharts';
import { ArrowUpRight, TrendingUp, TrendingDown, Users, BadgeDollarSign, Activity, Target } from 'lucide-react';

const revData = [
  { name: 'Mon', total: 12400 },
  { name: 'Tue', total: 14000 },
  { name: 'Wed', total: 13500 },
  { name: 'Thu', total: 17800 },
  { name: 'Fri', total: 21000 },
  { name: 'Sat', total: 19500 },
  { name: 'Sun', total: 24500 },
];

const repData = [
  { name: 'Alex C.', sales: 45000, color: '#10B981' },
  { name: 'Sarah M.', sales: 38000, color: '#60A5FA' },
  { name: 'John D.', sales: 29000, color: '#EAB308' },
  { name: 'Mike T.', sales: 18000, color: '#F87171' },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#242426] border border-white/10 px-3 py-2 rounded-xl shadow-xl">
        <p className="text-[13px] font-bold text-white tracking-tight">${payload[0].value.toLocaleString()}</p>
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 mt-2 px-5 pb-8">
      <div className="flex justify-between items-end mb-6">
        <div>
          <div className="text-[13px] font-bold text-[#EAB308] uppercase tracking-[0.08em] mb-1 flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5" /> Owner Exclusive
          </div>
          <h1 className="text-[28px] font-bold tracking-tight leading-none">Analytics</h1>
        </div>
        <div className="bg-[#242426] p-2 rounded-full cursor-pointer hover:bg-white/10 transition-colors">
          <Activity className="w-5 h-5 text-white" />
        </div>
      </div>

      {/* --- Main Metric & Chart --- */}
      <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04] mb-4">
        <div className="flex justify-between items-start mb-6">
          <div>
            <div className="text-[13px] text-zinc-400 font-medium tracking-tight mb-1">Weekly Revenue</div>
            <div className="text-[32px] text-white font-bold tracking-tight leading-none">$122,700</div>
          </div>
          <div className="flex items-center gap-1 bg-[#10B981]/10 text-[#10B981] px-2 py-1 rounded-lg">
            <TrendingUp className="w-3.5 h-3.5" />
            <span className="text-[13px] font-bold tracking-tight">+14.2%</span>
          </div>
        </div>

        <div className="h-[140px] w-full -ml-3">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={revData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#EAB308" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1, strokeDasharray: '4 4' }} />
              <XAxis dataKey="name" hide />
              <YAxis hide domain={['dataMin - 1000', 'dataMax + 2000']} />
              <Area type="monotone" dataKey="total" stroke="#EAB308" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* --- Two Column Bento --- */}
      <div className="flex gap-4 mb-4">
        <div className="bg-[#1C1C1E] rounded-[24px] p-4 flex-1 shadow-sm border border-white/[0.04]">
          <div className="w-8 h-8 rounded-full bg-[#60A5FA]/20 flex items-center justify-center mb-3">
            <Users className="w-4 h-4 text-[#60A5FA]" />
          </div>
          <div className="text-[12px] text-zinc-400 font-medium tracking-tight mb-0.5">Active Reps</div>
          <div className="text-[20px] text-white font-bold tracking-tight">12/14</div>
        </div>
        <div className="bg-[#1C1C1E] rounded-[24px] p-4 flex-1 shadow-sm border border-white/[0.04]">
          <div className="w-8 h-8 rounded-full bg-[#F87171]/20 flex items-center justify-center mb-3">
            <BadgeDollarSign className="w-4 h-4 text-[#F87171]" />
          </div>
          <div className="text-[12px] text-zinc-400 font-medium tracking-tight mb-0.5">At Risk Debt</div>
          <div className="text-[20px] text-[#F87171] font-bold tracking-tight">$34.5k</div>
        </div>
      </div>

      {/* --- Top Performers --- */}
      <div className="bg-[#1C1C1E] rounded-[24px] p-5 shadow-sm border border-white/[0.04]">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-[18px] font-bold tracking-tight text-white">Top Sales Reps</h3>
          <span className="text-[13px] text-zinc-500 font-medium tracking-tight">This Month</span>
        </div>
        
        <div className="space-y-4">
          {repData.map((rep, idx) => (
            <div key={rep.name} className="flex items-center gap-3">
              <div className="w-5 text-[15px] font-bold text-zinc-500 tracking-tight">{idx + 1}</div>
              <div className="flex-1">
                 <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[15px] font-bold text-white tracking-tight">{rep.name}</span>
                    <span className="text-[14px] font-medium text-zinc-400 tracking-tight">${rep.sales.toLocaleString()}</span>
                 </div>
                 {/* Custom progress bar */}
                 <div className="h-1.5 w-full bg-white/[0.05] rounded-full overflow-hidden">
                    <div 
                      style={{ width: `${(rep.sales / 45000) * 100}%`, backgroundColor: rep.color }} 
                      className="h-full rounded-full"
                    />
                 </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

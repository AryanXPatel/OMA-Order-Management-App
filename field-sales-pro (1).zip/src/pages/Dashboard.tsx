import React from 'react';
import { ChevronRight, MoreHorizontal, FileClock, ChevronRightCircle, CheckCircle2, PackageOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      {/* --- Section 1: Dashboard Metrics --- */}
      <div className="mt-6 px-5">
          <div className="flex items-center justify-between mb-4 px-1">
            <h2 className="text-[22px] font-bold tracking-tight flex items-center gap-1">
              Dashboard <ChevronRight className="w-[22px] h-[22px] text-zinc-500 mt-0.5" strokeWidth={2.5}/>
            </h2>
            <MoreHorizontal className="w-5 h-5 text-zinc-600"/>
          </div>
          
          <div className="bg-[#1C1C1E] rounded-[24px] px-5 py-5 shadow-sm">
              <div className="text-[12px] font-bold text-[#EAB308] uppercase tracking-[0.08em] mb-4">
                TODAY, APR 19
              </div>
              
              <div className="flex items-center justify-between mb-5 pl-3.5 relative">
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] rounded-full bg-[#EAB308]"></div>
                  <span className="text-[#EAB308] font-medium text-[17px] tracking-tight">Today's Revenue</span>
                  <span className="text-[#EAB308] text-[15px] font-bold opacity-90 tracking-tight">$12,450.00</span>
              </div>

              <div className="text-[12px] font-bold text-zinc-500 uppercase tracking-[0.08em] mb-4 mt-8">
                ACTIVE PIPELINE
              </div>

              <div className="flex items-center justify-between mb-4 pl-3.5 relative">
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] rounded-full bg-[#60A5FA]"></div>
                  <span className="flex flex-col">
                     <span className="text-[#60A5FA] font-medium text-[17px] tracking-tight">Orders Processing</span>
                     <span className="text-[#60A5FA]/60 text-[13px] tracking-tight">Warehouse fulfillment</span>
                  </span>
                  <span className="text-[#60A5FA] text-[15px] font-bold opacity-90 tracking-tight">24</span>
              </div>

              <div className="flex items-center justify-between pl-3.5 relative">
                  <div className="absolute left-0 top-0 bottom-0 w-[3px] rounded-full bg-[#F87171]"></div>
                  <span className="text-[#F87171] font-medium text-[17px] tracking-tight">Pending Deliveries</span>
                  <span className="text-[#F87171] text-[15px] font-bold opacity-90 tracking-tight">8</span>
              </div>
          </div>
      </div>

      {/* --- Section 2: Action Required / Approvals --- */}
      <div className="mt-8 px-5">
          <div className="flex items-center justify-between mb-4 px-1">
            <h2 className="text-[22px] font-bold tracking-tight flex items-center gap-1">
              Approvals <ChevronRight className="w-[22px] h-[22px] text-zinc-500 mt-0.5" strokeWidth={2.5}/>
            </h2>
            <MoreHorizontal className="w-5 h-5 text-zinc-600"/>
          </div>

          <div className="bg-[#1C1C1E] rounded-[24px] p-2 shadow-sm">
              <div className="p-3.5 border-b border-white/[0.06] flex items-start gap-4">
                  <div className="w-[28px] h-[28px] rounded-full bg-[#F87171]/20 border border-[#F87171]/30 flex items-center justify-center shrink-0 mt-[2px]">
                      <FileClock className="w-[14px] h-[14px] text-[#F87171]" strokeWidth={2.5} />
                  </div>
                  <div className="min-w-0 flex-1">
                      <div className="flex justify-between items-start mb-0.5">
                         <div className="text-[17px] text-white tracking-tight truncate leading-tight">Acme Corp</div>
                         <div className="text-[15px] text-white font-semibold">$4,200</div>
                      </div>
                      <div className="text-[13px] text-[#F87171] font-medium flex items-center gap-1 tracking-tight truncate">
                          Requires credit limit override
                      </div>
                  </div>
              </div>
              <div className="p-3.5 border-b border-white/[0.06] flex items-start gap-4">
                  <div className="w-[28px] h-[28px] rounded-full bg-[#EAB308]/20 border border-[#EAB308]/30 flex items-center justify-center shrink-0 mt-[2px]">
                      <FileClock className="w-[14px] h-[14px] text-[#EAB308]" strokeWidth={2.5} />
                  </div>
                  <div className="min-w-0 flex-1">
                      <div className="flex justify-between items-start mb-0.5">
                         <div className="text-[17px] text-white tracking-tight truncate leading-tight">Globex Inc</div>
                         <div className="text-[15px] text-white font-semibold">$850</div>
                      </div>
                      <div className="text-[13px] text-[#EAB308] font-medium flex items-center gap-1 tracking-tight truncate">
                          Manager discount approval
                      </div>
                  </div>
              </div>
              <div className="p-3.5 flex items-start gap-4 cursor-pointer hover:bg-white/[0.02] rounded-b-[20px] transition-colors" onClick={() => navigate('/approvals')}>
                  <div className="w-[28px] h-[28px] rounded-full flex items-center justify-center shrink-0 mt-[2px]">
                      <ChevronRightCircle className="w-[20px] h-[20px] text-zinc-500" strokeWidth={2} />
                  </div>
                  <div className="min-w-0 flex flex-col justify-center h-[28px] mt-[2px]">
                      <div className="text-[15px] text-zinc-500 font-medium tracking-tight">View 12 more pending</div>
                  </div>
              </div>
          </div>
      </div>

      {/* --- Section 3: Recent Orders --- */}
      <div className="mt-8">
          <div className="flex justify-between items-end mb-4 px-6">
              <h2 className="text-[22px] font-bold tracking-tight flex items-center gap-1">
                My Orders <ChevronRight className="w-[22px] h-[22px] text-zinc-500 mt-0.5" strokeWidth={2.5}/>
              </h2>
              <div className="flex gap-4 text-[14px] mb-0.5">
                  <button className="text-white tracking-tight">Recent</button>
              </div>
          </div>
          
          <div className="flex gap-[14px] overflow-x-auto pb-6 px-5 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              <div className="w-[240px] shrink-0 bg-[#1C1C1E] rounded-[22px] p-5 shadow-[0_2px_10px_rgba(0,0,0,0.2)] border border-white/[0.03]">
                  <div className="flex justify-between items-center mb-4 tracking-tight">
                      <div className="flex items-center gap-1.5 text-[12px] font-semibold text-zinc-400 bg-zinc-800/50 px-2 py-0.5 rounded-md">
                        #ORD-992
                      </div>
                      <div className="text-[12px] text-zinc-500">2h ago</div>
                  </div>
                  <div className="mb-5">
                      <h3 className="text-[20px] leading-tight font-semibold tracking-tight text-white mb-1">Stark Industries</h3>
                      <div className="flex items-center gap-1.5 text-[13px] font-medium text-[#10B981]">
                         <CheckCircle2 className="w-3.5 h-3.5" /> Credit Approved
                      </div>
                  </div>
                  <div className="space-y-2.5">
                      <div className="flex justify-between items-center text-[14px] tracking-tight border-t border-white/[0.04] pt-3">
                          <span className="text-zinc-400">Total Amount</span>
                          <span className="text-white font-semibold">$12,050.00</span>
                      </div>
                      <div className="flex justify-between items-center text-[14px] tracking-tight">
                          <span className="text-zinc-400">Order Size</span>
                          <span className="text-white font-medium">124 Items</span>
                      </div>
                  </div>
              </div>

              <div className="w-[240px] shrink-0 bg-[#1C1C1E] rounded-[22px] p-5 shadow-[0_2px_10px_rgba(0,0,0,0.2)] border border-white/[0.03]">
                  <div className="flex justify-between items-center mb-4 tracking-tight">
                      <div className="flex items-center gap-1.5 text-[12px] font-semibold text-zinc-400 bg-zinc-800/50 px-2 py-0.5 rounded-md">
                        #ORD-991
                      </div>
                      <div className="text-[12px] text-zinc-500">5h ago</div>
                  </div>
                  <div className="mb-5">
                      <h3 className="text-[20px] leading-tight font-semibold tracking-tight text-white mb-1">Wayne Enterprises</h3>
                      <div className="flex items-center gap-1.5 text-[13px] font-medium text-[#60A5FA]">
                         <PackageOpen className="w-3.5 h-3.5" /> Processing Dispatch
                      </div>
                  </div>
                  <div className="space-y-2.5">
                      <div className="flex justify-between items-center text-[14px] tracking-tight border-t border-white/[0.04] pt-3">
                          <span className="text-zinc-400">Total Amount</span>
                          <span className="text-white font-semibold">$3,400.00</span>
                      </div>
                      <div className="flex justify-between items-center text-[14px] tracking-tight">
                          <span className="text-zinc-400">Order Size</span>
                          <span className="text-white font-medium">15 Items</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}

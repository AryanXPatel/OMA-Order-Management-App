import React, { useContext } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Bell, MoreHorizontal, LayoutGrid, PackageOpen, Users, BadgeDollarSign, Plus, BarChart2 } from 'lucide-react';
import { RoleContext } from '../App';

export default function MobileLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const activeTab = location.pathname;
  const { role, setRole } = useContext(RoleContext);

  return (
    <div className="min-h-screen bg-[#000000] flex justify-center font-sans sm:py-8 lg:p-12 text-white selection:bg-blue-500/30">
      <div className="w-full max-w-[414px] bg-[#121212] sm:rounded-[56px] min-h-[100dvh] sm:min-h-[896px] shadow-2xl relative flex flex-col overflow-hidden sm:ring-[6px] sm:ring-[#2C2C2E]">
        
        {/* Header */}
        <div className="pt-14 px-6 flex justify-between items-center z-10 relative mb-2 shrink-0">
          <div className="flex items-center gap-3">
            <img src="https://i.pravatar.cc/150?img=11" alt="Profile" className="w-[38px] h-[38px] rounded-full object-cover border border-white/10" />
            <div>
              <div className="text-[13px] font-medium text-zinc-400 tracking-tight leading-none mb-1">
                <select 
                  value={role} 
                  onChange={(e) => {
                    setRole(e.target.value as any);
                    if (e.target.value === 'worker' && activeTab === '/clients') navigate('/');
                    if (e.target.value !== 'owner' && activeTab === '/analytics') navigate('/');
                  }}
                  className="bg-transparent outline-none cursor-pointer hover:text-white transition-colors"
                >
                  <option value="owner" className="bg-[#1C1C1E]">Owner</option>
                  <option value="manager" className="bg-[#1C1C1E]">Manager</option>
                  <option value="worker" className="bg-[#1C1C1E]">Worker</option>
                </select>
              </div>
              <div className="text-[17px] font-semibold tracking-tight leading-none">Alex Carter</div>
            </div>
          </div>
          <div className="bg-[#242426] rounded-full px-[14px] py-[10px] flex items-center gap-[18px] shadow-sm">
             {role === 'owner' && (
               <BarChart2 
                 onClick={() => navigate('/analytics')}
                 className={`w-[18px] h-[18px] cursor-pointer transition-colors stroke-[2.2] ${activeTab === '/analytics' ? 'text-[#EAB308]' : 'text-zinc-300 hover:text-white'}`} 
               />
             )}
             <Bell className="w-[18px] h-[18px] text-zinc-300 stroke-[2.2]" />
          </div>
        </div>

        {/* Scrollable Content */}
        <div className={activeTab === '/analytics' ? "flex-1 overflow-y-auto pb-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]" : "flex-1 overflow-y-auto pb-[180px] [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"}>
          <Outlet />
        </div>

        {/* Bottom Nav - Hidden on Analytics to give Owner full real estate, or keep it depending on preference. Let's hide it purely on Analytics to show specialized focused mode */}
        {activeTab !== '/analytics' && (
          <>
            <div className="absolute bottom-0 left-0 right-0 h-[180px] bg-gradient-to-t from-[#121212] via-[#121212]/90 to-transparent pointer-events-none z-20"></div>

            <div className="absolute bottom-[34px] left-5 right-5 flex gap-[10px] z-30">
                <div className="flex-1 bg-[#2C2C2E]/90 backdrop-blur-[24px] rounded-[32px] flex justify-between items-center px-2 py-2 border border-white/[0.08] shadow-2xl">
                    <button 
                      onClick={() => navigate('/')}
                      className={`flex flex-col items-center justify-center w-[64px] h-[56px] relative group transition-colors rounded-[24px] ${activeTab === '/' ? 'text-white bg-white/10' : 'text-zinc-400 hover:text-white'}`}
                    >
                        <LayoutGrid className="w-[22px] h-[22px] relative z-10 stroke-[1.8]" />
                        <span className="text-[10px] font-bold tracking-tight mt-1 relative z-10">Home</span>
                    </button>
                    <button 
                      onClick={() => navigate('/orders')}
                      className={`flex flex-col items-center justify-center w-[64px] h-[56px] relative group transition-colors rounded-[24px] ${activeTab === '/orders' ? 'text-white bg-white/10' : 'text-zinc-400 hover:text-white'}`}
                    >
                        <PackageOpen className="w-[22px] h-[22px] stroke-[1.8]" />
                        <span className="text-[10px] font-bold tracking-tight mt-1">Orders</span>
                    </button>
                    {role !== 'worker' && (
                      <button 
                        onClick={() => navigate('/clients')}
                        className={`flex flex-col items-center justify-center w-[64px] h-[56px] relative group transition-colors rounded-[24px] ${activeTab === '/clients' ? 'text-white bg-white/10' : 'text-zinc-400 hover:text-white'}`}
                      >
                          <Users className="w-[22px] h-[22px] stroke-[1.8]" />
                          <span className="text-[10px] font-bold tracking-tight mt-1">Clients</span>
                      </button>
                    )}
                    <button 
                      onClick={() => navigate('/approvals')}
                      className={`flex flex-col items-center justify-center w-[64px] h-[56px] relative group transition-colors rounded-[24px] ${activeTab === '/approvals' ? 'text-white bg-white/10' : 'text-zinc-400 hover:text-white'}`}
                    >
                        <BadgeDollarSign className="w-[22px] h-[22px] stroke-[1.8]" />
                        <span className="text-[10px] font-bold tracking-tight mt-1">Approvals</span>
                    </button>
                </div>
                
                <button 
                  onClick={() => navigate('/new-order')}
                  className="w-[72px] h-[72px] shrink-0 bg-white shadow-[0_8px_30px_rgba(255,255,255,0.2)] rounded-full flex items-center justify-center text-black hover:scale-[0.98] active:scale-[0.95] transition-transform group"
                >
                    <Plus className="w-[32px] h-[32px] stroke-[2]" />
                </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
